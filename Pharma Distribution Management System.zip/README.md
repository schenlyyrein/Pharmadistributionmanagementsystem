
  # Pharma Distribution Management System

  This is a code bundle for Pharma Distribution Management System. The original project is available at https://www.figma.com/design/Fl4hGmw2RESQoKXa4y76Pt/Pharma-Distribution-Management-System.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  